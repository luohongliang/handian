This is an example of a Sankey diagram made using d3.js and the sankey plugin. 

It has a point of differenc from other Sankey diagrams I have seen in that the nodes can be moved horizontally *and* vertically. 

A description of how it was put together and techniques for implimenting Sankey diagrams in general with d3.js can be found at [d3noob.org](http://www.d3noob.org/) or you can download the full text in the D3 Tips and Tricks book (for free) from [Leanpub](https://leanpub.com/D3-Tips-and-Tricks).

The data is sourced from the World Resources Institute (http://www.wri.org/chart/world-greenhouse-gas-emissions-2005).
Open in full window for full effect.